# Global CORS Custom Policy
=== 
API Platform already contains a CORS policy that you can apply to your API. The problem with this approach is that it's only applied to the API resources and not to the API Platform resources in general. For example the OAuth actions (/access-token). 

This policy applies to **ALL** resources on the API, even those that are automatically added by the API Platform