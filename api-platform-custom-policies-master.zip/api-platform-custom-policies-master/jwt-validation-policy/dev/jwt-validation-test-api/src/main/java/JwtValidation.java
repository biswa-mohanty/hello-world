import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.Signature;
import java.security.SignatureException;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;
import java.time.Instant;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.codehaus.jackson.map.ObjectMapper;
import org.mule.api.MuleEventContext;
import org.mule.api.MuleMessage;
import org.mule.api.lifecycle.Callable;
import org.mule.api.transport.PropertyScope;

public class JwtValidation implements Callable {

	private Log logger = LogFactory.getLog("JwtValidationPolicy");

//	private Map algorithmMap = [ "HS256": "HmacSHA256", "HS384": "HmacSHA384", "HS512": "HmacSHA512",
//	                             "RS256": "SHA256withRSA", "RS384": "SHA384withRSA", "RS512": "SHA512withRSA" ,
//	                             "ES256": "SHA256withECDSA", "ES384": "SHA384withECDSA", "ES512": "SHA512withECDSA"];
	
	private Map<String, String> algorithmMap = MapUtils.putAll(new HashMap<String, String>(),
			new String[][] { { "HS256", "HmacSHA256" }, { "HS384", "HmacSHA384" }, { "HS512", "HmacSHA512" },
					{ "RS256", "SHA256withRSA" }, { "RS384", "SHA384withRSA" }, { "RS512", "SHA512withRSA" },
					{ "ES256", "SHA256withECDSA" }, { "ES384", "SHA384withECDSA" }, { "ES512", "SHA512withECDSA" } });

	public class JWT {
		String headerBase64;
		String headerJson;
		Map<String, Object> header;
		String payloadBase64;
		String payloadJson;
		Map<String, Object> payload;
		String signatureBase64;
		byte[] signature;
		Integer parts;
		Boolean validSignature;

		String getAlgorithm() {
			return ((String) header.get("alg"));
		}

		boolean isHMAC() {
			return getAlgorithm().startsWith("HS");
		}

		boolean isRSA() {
			return getAlgorithm().startsWith("RS");
		}

		boolean isECDSA() {
			return getAlgorithm().startsWith("HS");
		}

		boolean isUnsecure() {
			return getAlgorithm().equals("none");
		}

		public Map<String, Object> getHeader() {
			return header;
		}

		public Map<String, Object> getPayload() {
			return payload;
		}

		public Boolean getValidSignature() {
			return validSignature;
		}
		
		public String toString() {
			return ToStringBuilder.reflectionToString(this);
		}

	}

	@Override
	public Object onCall(MuleEventContext eventContext) throws Exception {
		logger.debug("Validating JWT");
		MuleMessage message = eventContext.getMessage();
		String httpAuthorization = message.getProperty("Authorization", PropertyScope.INBOUND);
		String certificate = message.getProperty("key", PropertyScope.INVOCATION);
		String issuer = message.getProperty("issuer", PropertyScope.INVOCATION);
		String audience = message.getProperty("audience", PropertyScope.INVOCATION);
		Integer expirationTolerance = Integer.valueOf(message.getProperty("expirationTolerance", PropertyScope.INVOCATION));
		Boolean checkExpiration = Boolean.valueOf(message.getProperty("checkExpiration", PropertyScope.INVOCATION));
		Boolean checkNotBefore = Boolean.valueOf(message.getProperty("checkNotBefore", PropertyScope.INVOCATION));
		Boolean allowUnsecuredTokens = Boolean.valueOf(message.getProperty("allowUnsecuredTokens", PropertyScope.INVOCATION));
		logger.debug("Configuration loaded");
		
		try {
			logger.debug("Validating HTTP Header");
			validateAuthHeader(httpAuthorization);
			logger.debug("Parsing token");
			JWT token = parseJwt(httpAuthorization.split(" ")[1], allowUnsecuredTokens);
			logger.debug("Token: " + token + "\nChecking usecured token");
			validateUnsecuredToken(token, allowUnsecuredTokens);
			logger.debug("Validating signature");
			validateSignature(token, certificate);
			logger.debug("Validating issuer");
			validateIssuer(token, issuer);
			logger.debug("Validating audience");
			validateAudience(token, audience);
			logger.debug("Validating checkExpiration");
			validateExpiration(token, checkExpiration, expirationTolerance);
			logger.debug("Validating checkNotBefore");
			validateNotBefore(token, checkNotBefore);
			message.setProperty("validToken", true, PropertyScope.INVOCATION);
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			message.setProperty("validToken", false, PropertyScope.INVOCATION);
			message.setProperty("errorMessage", e.getMessage(), PropertyScope.INVOCATION);
		}
		return message;
	}

	void validateAuthHeader(String authHeader) {
		if (authHeader == null || authHeader.length() == 0) {
			throw new RuntimeException("Missing Authorization header");
		} else if (!authHeader.toLowerCase().startsWith("bearer ")) {
			throw new RuntimeException("Malformed Authorization header. No Bearer scheme");
		} else if (authHeader.length() <= 7) {
			throw new RuntimeException("Malformed Authorization header. No token");
		}
	}

	private JWT parseJwt(String jwt, Boolean allowUnsecuredTokens) {
		JWT token = new JWT();
		String[] jwtSplitted = jwt.split("\\.");
		token.parts = jwtSplitted.length;
		if (!allowUnsecuredTokens && token.parts != 3) {
			throw new RuntimeException("JWT has " + token.parts + " parts.");
		}
		if (allowUnsecuredTokens && (token.parts < 2 || token.parts > 3)) {
			throw new RuntimeException("JWT has " + token.parts + " parts.");
		}
		token.headerBase64 = jwtSplitted[0];
		token.payloadBase64 = jwtSplitted[1];
		if (token.parts.equals(3)) {
			token.signatureBase64 = jwtSplitted[2];
		}
		try {
			token.headerJson = new String(Base64.decodeBase64(token.headerBase64));
			token.payloadJson = new String(Base64.decodeBase64(token.payloadBase64));
			if (token.parts.equals(3)) {
				token.signature = Base64.decodeBase64(token.signatureBase64);
			}
		} catch (Exception e) {
			throw new RuntimeException("Error decoding Base64");
		}
		try {
			token.header = parseJson(token.headerJson);
			token.payload = parseJson(token.payloadJson);
		} catch (Exception e) {
			throw new RuntimeException("Error parsing JSON");
		}
		if (token.getAlgorithm() == null || token.getAlgorithm().length() == 0) {
			throw new RuntimeException("JWT header does not contain 'alg' attribute");
		}
		return token;
	}

	private Map<String, Object> parseJson(String json) throws Exception {
		return new ObjectMapper().readValue(json.getBytes(), HashMap.class);
	}

	private void validateUnsecuredToken(JWT token, Boolean allowUnsecuredTokens) {
		if (token.isUnsecure() && !allowUnsecuredTokens) {
			throw new RuntimeException("Unsecured tokens are not valid by configuration.");
		}
	}
	
	private void validateSignature(JWT token, String certificate) {
		if (!token.isUnsecure()) {
			if (token.isHMAC()) {
				validateSymmetricTokenSignature(token, certificate);
			} else if (token.isRSA() || token.isECDSA()) {
				validateAsymmetricTokenSignature(token, certificate);
			} else {
				throw new RuntimeException(
						"JWT header 'alg' with value '" + token.getAlgorithm() + "' is not supported.");
			}
		}
	}

	private void validateAsymmetricTokenSignature(JWT token, String certificate) {
		try {
			byte[] pk = Base64.decodeBase64(certificate);
			X509EncodedKeySpec pubKeySpec = new X509EncodedKeySpec(pk);
			KeyFactory keyFactory = null;
			if (token.isRSA()) {
				keyFactory = KeyFactory.getInstance("RSA");
			} else if (token.isECDSA()) {
				keyFactory = KeyFactory.getInstance("ECDSA");
			}
			PublicKey publicKey = keyFactory.generatePublic(pubKeySpec);
			String javaAlgorithm = algorithmMap.get(token.getAlgorithm());
			if (javaAlgorithm == null) {
				throw new RuntimeException(
						"JWT header 'alg' key size with value '" + token.getAlgorithm() + "' is not supported.");
			}
			Signature signature = Signature.getInstance(javaAlgorithm);
			signature.initVerify(publicKey);
			signature.update((token.headerBase64 + '.' + token.payloadBase64).getBytes());
			token.validSignature = signature.verify(token.signature);
		} catch (SignatureException | NoSuchAlgorithmException | InvalidKeySpecException | InvalidKeyException e) {
			throw new RuntimeException("Error validating token signature: " + e.getMessage(), e);
		}
	}

	private void validateSymmetricTokenSignature(JWT token, String certificate) {
		try {
			String javaAlgorithm = algorithmMap.get(token.getAlgorithm());
			if (javaAlgorithm == null) {
				throw new RuntimeException(
						"JWT header 'alg' key size  with value '" + token.getAlgorithm() + "' is not supported.");
			}
			Mac macAlgorithm = Mac.getInstance(javaAlgorithm);
			SecretKeySpec secret_key = new SecretKeySpec(certificate.getBytes(),
					algorithmMap.get(token.getAlgorithm()));
			macAlgorithm.init(secret_key);

			byte[] signature = macAlgorithm.doFinal((token.headerBase64 + '.' + token.payloadBase64).getBytes());
			token.validSignature = Arrays.equals(signature, token.signature);
		} catch (NoSuchAlgorithmException | InvalidKeyException | IllegalStateException e) {
			throw new RuntimeException("Error validating token signature: " + e.getMessage(), e);

		}

	}

	private void validateIssuer(JWT token, String issuer) {
		if (issuer != null && issuer.length() > 0) {
			String iss = (String) token.payload.get("iss");
			if (iss == null) {
				throw new RuntimeException("JWT payload does not contain 'iss' claim");
			}
			if (!iss.equals(issuer)) {
				throw new RuntimeException("'iss' claim with value '" + iss + "' differs from required issuer");
			}
		}

	}

	private void validateAudience(JWT token, String audience) {
		if (audience != null && audience.length() > 0) {
			String aud = (String) token.payload.get("aud");
			if (aud == null) {
				throw new RuntimeException("JWT payload does not contain 'aud' claim.");
			}
			if (!aud.equals(audience)) {
				throw new RuntimeException("'aud' claim with value '" + aud + "' differs from required audience.");
			}
		}
	}

	private void validateExpiration(JWT token, Boolean checkExpiration, Integer expirationTolerance) {
		if (checkExpiration != null && checkExpiration) {
			Long exp = (Long) token.payload.get("exp");
			exp = exp + expirationTolerance;
			Long now = Instant.now().getEpochSecond();
			if (now > exp) {
				throw new RuntimeException("JWT token is expired. exp: " + exp + " actual: " + now);
			}
		}
	}

	private void validateNotBefore(JWT token, Boolean checkNotBefore) {
		if (checkNotBefore != null && checkNotBefore) {
			Long nbf = (Long) token.payload.get("nbf");
			Long now = Instant.now().getEpochSecond();
			if (now < nbf) {
				throw new RuntimeException("JWT token is not yet valid. nbf: " + nbf + " actual: " + now);
			}
		}
	}
}
