import java.io.ByteArrayInputStream;
import java.security.Key;
import java.security.KeyStore;

import org.apache.commons.codec.binary.Base64;
import org.opensaml.DefaultBootstrap;
import org.opensaml.saml2.core.Assertion;
import org.opensaml.saml2.core.Response;
import org.opensaml.saml2.core.impl.ResponseMarshaller;
import org.opensaml.xml.Configuration;
import org.opensaml.xml.io.MarshallingException;
import org.opensaml.xml.security.SecurityConfiguration;
import org.opensaml.xml.security.SecurityHelper;
import org.opensaml.xml.security.x509.BasicX509Credential;
import org.opensaml.xml.signature.Signature;
import org.opensaml.xml.signature.Signer;
import org.opensaml.xml.util.XMLHelper;
import org.w3c.dom.Element;

public class OpenSAMLTest {

	String ksString = "MIIKDAIBAzCCCcYGCSqGSIb3DQEHAaCCCbcEggmzMIIJrzCCBWQGCSqGSIb3DQEHAaCCBVUEggVRMIIFTTCCBUkGCyqGSIb3DQEMCgECoIIE+jCCBPYwKAYKKoZIhvcNAQwBAzAaBBRXkavOrhzMitQAHMMc1hqvczagOgICBAAEggTICrkwlV+rxPMIDNh6+V59Isdvhho+arOzz2yZvRh0UPeewfkFQlIf9BnBKk/1xG2KpsH+Jq26qyASUugNHDWiS7g5YRezJGjPyD4+KcDHmsSwODJaocNKghq/Pr/OuWra0x9JQOl5nfxzG1xUGOkRoPjXw2J7NMcxGlyYB0WTicbqRvxtBF5CRB4ZikGEwIz/cbusEYwF3CCar9wKQ69Er4j7ShDI3CtebVRm0DJ275YCC2LYZdDbrSXv/f8SX7IGLk6PfN7j5ViHl55juD5gt3jjxNSjbvy88xW+SuOUyQfXfM/ijUEFLr4p5FtqQGzsTocG0345Nh/Rf4vPTfz1TbLEmx8r3TiUHx53UuRgw1Z0gOVJhey+tR/jYcomHIRLEI0FFcUVI8Jyi7zOjviqML5psjy60F8B7xmrgYHPz5fuzOcKOjWFqdHQHLHrEQOWdX5bLNzSi6VEiU/uhj1yB13UqVbBkLHNKOUP6sdFkbwUQbUq7pqmqPXnuoBoYOKDf6q5Hi26+0KxknyAft9CAGedpq9nMpxkpM+QDraCP6Wd1/XBW4DLn/yRQIsv0FpPpFGmWNOWBfmWenR0SUGeXHHZZl9iQAPMriPt0TD7sqEovrDrsPvDulGkY2uhBGhRrBq5zQwfBOQkq2q3/gPL+lswuzywfT1YTOn+PnFvdCGUoLLDmC28gIWXBkoxzih6At4n4hwS2qLMTasxEO1ZAXbNoCZmRvGzVPdZmM3oYXkVK+254eIp8lfeUBFf0MS1Rnz6nydFiW6bHhSkYPHgIReKKustTA3vnmGuoYywtQEJpntqkXMwsw28qNM9UWIg0Hb698WZFvlSUQfsEN9dGFftFeRRrcQ3nRvGxkmgiFYnfNgUDE2C0EF5ss8dyTTXQS0szZe262DIMByDrDcVMwcAYWjXCGnz2kBEadJ9UNbsqmlAELMuWYAvVHy5/wuBGOs+6fBozo93p4qaVrl7Q8hWlxCpcEQvxEj+oyN26O+nrXbaDIMcm01ZU6izsbar3U/oA+zP1eH0c65GyK0urXkb0JHF2XaB+z9A2ox+nWzduqXLml4JYdbA8O3nvD6A1V7nl0oBj3DYbSeA4swLT9n3IebTt0kL5cydAQOeu8T79bn6WVzvtDJPClsQDIImVSVPWYJrfPu0Tp4216+OmuWoogRVzzYTUZaxMtLgS1DKHaA5vmJb1/HhMcoy/rCm2OF9Bp8hb6rSMW7cHKZlk1cyrZDm2/Fj8NX+pVAQw94EZpwLLMtrhDXWopEsqYHpBqh6ppp87cAjuXHmR83GOVV1vKc6UHpLNyuTTXu8/42a44uArxgdTvPPM3VoVwsuFhJ5YowEp+0VkBNrMQcFxCnA/yi+tcyd6rIPGsa9Ce4g2+Kf+lzgktg9EjFicOQqyKq4YLUTxAQQf1vGPuMg0IMvgpgLDWJIxxiGcYccLrNfdOuOO2HL/U6Ovc6sc8hTy0dYvccxEgab2MMu4pESK9qBrsjW6LxB8jRZuTRHE2RuhTxe4+Kqx6ZNHIUBixglTEyy82VXjqBZ/KmDD/fyJT/VBgH3qJ28FX/hFq1z76VpHv6xNzCnO8jvQNFdvf4azlnU3hs3J5KBKTEYAMy8RpA+bJVsdxzgMTwwFwYJKoZIhvcNAQkUMQoeCABwAGkAbgBnMCEGCSqGSIb3DQEJFTEUBBJUaW1lIDE1MDYxMDc5OTIxNDgwggRDBgkqhkiG9w0BBwagggQ0MIIEMAIBADCCBCkGCSqGSIb3DQEHATAoBgoqhkiG9w0BDAEGMBoEFKdU3SdPuTduEKcG6+7QZDar55EjAgIEAICCA/BeM4Qb7nJzPahLRCnXzJo6omv32cWkGa5b1U9OLPiOMohWpSW8wzPiGAONHwMNT0Ew/A2I7FNAHxYwYWyjS8w70Jj0ipbrOKeXoUsZmGJJHafzbNf2a9wHC6hlg4W7bOXQgNG7k4bEoujpHrs6w3mmA5hdrIF9gtOHRje4Qi1fweDknhQxtvXWf4mE5jU4cKQltyJb0HwsSVwPTpbAAGRyVgpk/NWTrqp+xy9N7nkzb/hig+t8uwJx9N7A3ox1HKQm3Ku1oMYhtDUMe+Gt0XMNDLf5V/jZovjEXcdd0VyISBhC/NC5RElCijpGF1/IbooZM4N5NnACNXlOd1tBDE6F/qLRAo2PCHDVt4FhndQmzgSSLt+WxyekoeVMEGfyGN9j+gUEE7/27j7EKfEbh/yLY+jce0GWWsAhsObIoVVKvG3M/D5IdYP3jWCOoZ4cnsEFRCqcmqdE2C2uL4SHDoOHBbVoV30tHAwD9Ez23sBNxB1TW20frLl0c2tH+/AKEZZOIJRGcatswrA7lTP1OrOfuJL2YqGmoCxoKLnNMGCDNUBa/QAr91BLSQ45vCtTpEHHKVzZN0RKgGYC3peIigzEwlD0LqKh9VR2HX0VkQZljuvie2M9etkzAWwXryJGQXAWHzRjgdco6ejPvDSb0pv0nvL8TcqO3XlZclSt3rJzsbLBNGJHBOOrbfxi5dQ8cnWyTZqfG/FFjrNuAVaDpyDjr/5YZEPw6hbyUfZN+604OEEI574fxkyTA858cXOA93Kz4l8LOsCq0xyxzdpQxSKoinvJtuTFmIMMXu+DyeIWE0Ee/K07oYc9tMKBP5tnSalCqrCqLBb1yloidxn4VlJNfjn2m6D/8fPaeOb+U0at20qcvpkLJ9yRPngKTZZu04PItQOtwEn6Z4pZgq3AfC9JdVHrmN4xE7B4iScus3zskvaLANp8hpaOcJFik+E0n8FmMUrX4GLkmUbfbI/D/mmQZsAWBRGPhj+h9Te8Ttw96j907DSIurfx5uk8nF8km93nkkRysN3ovIKmz4H6DtfK7sSFa9DXIrI4qAbmgtyezlaMD3Gpgs6rlO/7RMdloJ+m1DzPNObgvvEMrxOUUoxvhXxgYpRwj8OZOJVr9s3/JrIp5Rv9vbAEhOQquMmgOJBahKebn0aMIiyaJQNKRmf+PQuoc6Wkym1zHOBKkJrkZq6oPUG2xaozrB6zaTbXhL+u5ysGc4WbD+sd1M79tsj9n4sSk1dOnvW5ptrzvWc1kUGfoY8JjNtUBPo8U/8w542oYhs8G0AVlmO6tcM5eU0d1bWAbEhl0lH1TKS2XRqEEaEaZt4xmzRBqo+muVix0P4wPTAhMAkGBSsOAwIaBQAEFKga+H042cXp8Sf0qXh5XLmYnhokBBSCXR8RR+Mk9ayQHV3oZAvT3p2jlAICBAA=";

	public static void main(String[] args) throws Exception {
		new OpenSAMLTest().run();
	}

	public void run() throws Exception {
		KeyStore ks = KeyStore.getInstance("pkcs12");
		ks.load(new ByteArrayInputStream(Base64.decodeBase64(ksString.getBytes())), "Mule1379".toCharArray());

		Signature signature = null;
		DefaultBootstrap.bootstrap();

		signature = (Signature) Configuration.getBuilderFactory().getBuilder(Signature.DEFAULT_ELEMENT_NAME)
				.buildObject(Signature.DEFAULT_ELEMENT_NAME);

		KeyStore.PrivateKeyEntry pkEntry = (KeyStore.PrivateKeyEntry) ks.getEntry("ping",
				new KeyStore.PasswordProtection("Mule1379".toCharArray()));

		BasicX509Credential signingCredential = new BasicX509Credential();
		signingCredential.setPrivateKey(pkEntry.getPrivateKey());

		signature.setSigningCredential(signingCredential);

		// This is also the default if a null SecurityConfiguration is specified
		SecurityConfiguration secConfig = Configuration.getGlobalSecurityConfiguration();
		// If null this would result in the default KeyInfoGenerator being used
		String keyInfoGeneratorProfile = "XMLSignature";

		try {
			SecurityHelper.prepareSignatureParams(signature, signingCredential, secConfig, null);
		} catch (SecurityException e) {
			e.printStackTrace();
		} catch (org.opensaml.xml.security.SecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Assertion resp = SAMLWriter.getSamlAssertion();

		resp.setSignature(signature);

		try {
			Configuration.getMarshallerFactory().getMarshaller(resp).marshall(resp);
		} catch (MarshallingException e) {
			e.printStackTrace();
		}

		Signer.signObject(signature);

		ResponseMarshaller marshaller = new ResponseMarshaller();
		Element plain = marshaller.marshall(resp);
		// response.setSignature(sign);
		String samlResponse = XMLHelper.nodeToString(plain);
		System.out.println(samlResponse);
	}

}
