
import java.io.ByteArrayInputStream;
import java.security.PublicKey;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;

import org.mule.api.MuleEventContext;
import org.mule.api.MuleMessage;
import org.mule.api.lifecycle.Callable;
import org.mule.api.transport.PropertyScope;
import org.opensaml.Configuration;
import org.opensaml.DefaultBootstrap;
import org.opensaml.saml2.core.Assertion;
import org.opensaml.security.SAMLSignatureProfileValidator;
import org.opensaml.xml.io.Unmarshaller;
import org.opensaml.xml.io.UnmarshallerFactory;
import org.opensaml.xml.io.UnmarshallingException;
import org.opensaml.xml.security.x509.BasicX509Credential;
import org.opensaml.xml.signature.Signature;
import org.opensaml.xml.signature.SignatureValidator;
import org.opensaml.xml.validation.ValidationException;
import org.w3c.dom.Element;

public class SAMLAssertionValidation implements Callable {

	private UnmarshallerFactory unmarshallerFactory;

	public SAMLAssertionValidation() throws Exception {
		unmarshallerFactory = Configuration.getUnmarshallerFactory();
		DefaultBootstrap.bootstrap();
	}

	@Override
	public Object onCall(MuleEventContext eventContext) throws Exception {
		MuleMessage message = eventContext.getMessage();
		Element assertionNode = message.getProperty("xmlAssertionNode", PropertyScope.INVOCATION);
		byte[] binaryCert = message.getProperty("binaryCert", PropertyScope.INVOCATION);
		try {
			samlAssertionValidation(assertionNode, binaryCert);
			message.setProperty("validAssertionSignature", true, PropertyScope.INVOCATION);
		} catch (Exception e) {
			message.setProperty("validAssertionSignature", false, PropertyScope.INVOCATION);
			message.setProperty("errorMessage", e.getMessage(), PropertyScope.INVOCATION);
		}
		return message;
	}

	public void samlAssertionValidation(Element assertionNode, byte[] binaryCert) {

		try {
			Unmarshaller unmarshaller = unmarshallerFactory.getUnmarshaller(assertionNode);

			Assertion assertion = (Assertion) unmarshaller.unmarshall(assertionNode);
			Signature signature = assertion.getSignature();

			CertificateFactory certificateFactory = CertificateFactory.getInstance("X.509");
			X509Certificate certificate = (X509Certificate) certificateFactory
					.generateCertificate(new ByteArrayInputStream(binaryCert));
			PublicKey publicKey = certificate.getPublicKey();

			SAMLSignatureProfileValidator profileValidator = new SAMLSignatureProfileValidator();
			profileValidator.validate(signature);
			BasicX509Credential publicCredential = new BasicX509Credential();
			publicCredential.setPublicKey(publicKey);
			SignatureValidator signatureValidator = new SignatureValidator(publicCredential);
			signatureValidator.validate(signature);

		} catch (UnmarshallingException e) {
			throw new RuntimeException("Error unmarshalling Assertion. " + e.getMessage(), e);
		} catch (CertificateException e) {
			throw new RuntimeException("Error creating or instantiating certificates. " + e.getMessage(), e);
		} catch (ValidationException e) {
			throw new RuntimeException("Certificate validation error. " + e.getMessage(), e);
		}

	}

}
