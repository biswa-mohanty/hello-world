# SAML Assertion Validation Policy

## Description
This policy applies validations over a SAML Assertion Token. It includes issuer
and signature verification. It also provides an option to remove the Security
SOAP header.

This policy is configured with an inline cert, there is no need of JKS
configuration so it can be used on CloudHub.

If the validation is successful, it leaves a flow variable with the assertion
data.

## Assertion data

The policy leaves a flow variable called 'assertionData' with an structure
like the following one:

```
{
  issuer: "mulesoft",
  subject: {
    nameId: "admin"
  },
  conditions: {
    notBefore: "2017-09-19T14:46:43.018Z",
    notOnOrAfter: "2017-12-04T07:26:43.018Z",
    now: "2017-09-28T16:48:07.378-03:00",
    expired: false,
    audienceRestrictions: [
      {
        audience: "anypoint.cloud.presales"
      }
    ]
  },
  attributeStatement: {
    firstname: "Ross",
    lastname: "Mason",
    email: "ross.mason@mule.com"
  }
}
```
