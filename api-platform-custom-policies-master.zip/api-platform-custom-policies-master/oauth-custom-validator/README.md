This is a simple Oauth token validator for when you cannot or do not want to set up the anypoint platform to be tightly integrated with the Oauth provider.

This has been written and tested on PingFederate as an Oauth provider and is based on the calls described here:
https://developer.pingidentity.com/en/resources/oauth-2-0-developers-guide.html#validate_token

This was created for a PoC and the error handling is a bit basic - it does not differentiate between invalid token, missing token or unauthorised.

There is also no RAML snippet and other advanced policy features which could be added to productized this policy.
