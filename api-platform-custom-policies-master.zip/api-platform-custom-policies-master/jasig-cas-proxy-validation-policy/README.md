# JASIG-CAS SSO Proxy Ticket Validation Policy
====

# Systems Version
Built on API Gateway 1.3.1
JASIG-CAS 4.0.0

# Pre-requisite
Configure CAS to allow Proxy Authentication

deployerConfigContext.xml:

<util:list id="registeredServicesList">
        <bean class="org.jasig.cas.services.RegexRegisteredService"
              p:id="0" p:name="HTTP and IMAP"
              ...
              **p:allowedToProxy="true"**
              **p:ssoEnabled="true"**
              .../>



# Purpose
Policy enforcement based on CAS Proxy Ticket validation.

# Use Case
Propagate CAS Single-Sign-On session down to API Gateway to restrict API implementation access.

1. User login to a validate webapp protected by CAS
2. User requests a resource from the webapp leveraging an API protected by API Gateway
3. Webapp generates a Proxy Ticket (PT) using a dedicated ServiceName for this webapp
4. Webapp calls the API by passing the PT & ServiceName as http header
5. JASIG-CAS SSO Proxy Validation Policy calls CAS server to validate the {PT;ServiceName}
6. Upon successful validation, the policy generates an extra header CAS_Principal representing the end-user login name

For more detail information please refer to the sequence diagram
