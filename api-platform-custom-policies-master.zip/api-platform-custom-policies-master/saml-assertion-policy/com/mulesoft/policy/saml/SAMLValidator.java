package com.mulesoft.policy.saml;

import org.apache.ws.security.WSSecurityException;
import org.apache.ws.security.handler.RequestData;
import org.apache.ws.security.saml.ext.AssertionWrapper;
import org.apache.ws.security.saml.ext.OpenSAMLUtil;
import org.apache.ws.security.validate.Credential;
import org.apache.ws.security.validate.SamlAssertionValidator;

public class SAMLValidator extends SamlAssertionValidator {
	/*
	 * Copyright (c) MuleSoft, Inc. All rights reserved. http://www.mulesoft.com
	 * The software in this package is published under the terms of the CPAL
	 * v1.0 license, a copy of which has been included with this distribution in
	 * the LICENSE.txt file.
	 */

	private boolean requireSenderVouches;
	private String issuer;
	private String subject;
	

	@Override
	public Credential validate(Credential credential, RequestData data)
			throws WSSecurityException {
		Credential returnedCredential = super.validate(credential, data);

		//
		// Do some custom validation on the assertion
		//
		AssertionWrapper assertion = credential.getAssertion();
		if (getIssuer() != null && !getIssuer().equals(assertion.getIssuerString())) {
			throw new WSSecurityException(WSSecurityException.FAILURE,
					"invalidSAMLsecurity");
		}

		if (assertion.getSaml2() == null) {
			throw new WSSecurityException(WSSecurityException.FAILURE,
					"invalidSAMLsecurity");
		}

		String confirmationMethod = assertion.getConfirmationMethods().get(0);
		if (confirmationMethod == null) {
			throw new WSSecurityException(WSSecurityException.FAILURE,
					"invalidSAMLsecurity");
		}
		if (requireSenderVouches
				&& !OpenSAMLUtil.isMethodSenderVouches(confirmationMethod)) {
			throw new WSSecurityException(WSSecurityException.FAILURE,
					"invalidSAMLsecurity");
		} else if (!requireSenderVouches
				&& !OpenSAMLUtil.isMethodHolderOfKey(confirmationMethod)) {
			throw new WSSecurityException(WSSecurityException.FAILURE,
					"invalidSAMLsecurity");
		}

		if (getSubject() != null && !getSubject().equals(assertion
				.getSaml2().getSubject().getNameID().getValue())) {
			throw new WSSecurityException(WSSecurityException.FAILURE,
					"invalidSAMLsecurity");
		}

		return returnedCredential;
	}

	public String getIssuer() {
		return issuer;
	}

	public void setIssuer(String issuer) {
		this.issuer = issuer;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public boolean isRequireSenderVouches() {
		return requireSenderVouches;
	}
	
	public void setRequireSenderVouches(boolean requireSenderVouches) {
		this.requireSenderVouches = requireSenderVouches;
	}

}
