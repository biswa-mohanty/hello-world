# Method-level no-db acl policy

## What is this?
This Policy allows to pass a token to an external validation API to authenticate a user.
It was built to authorize requests through an Okta System API.

## How to use?
1. Add the policy https://docs.mulesoft.com/api-manager/add-custom-policy-task
2. When applying the policy, you just need to configure the validation API endpoint: host, base uri and validation method.