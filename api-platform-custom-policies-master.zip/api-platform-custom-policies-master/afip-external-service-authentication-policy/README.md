### External API Rate Limiting Policy ###

This policy filters all API requests and based on a call to an external API. In this case it's a book2look APIP that says that in order for the user to consume the API the lookups ratio (lookups/bookings -> all fields of the external API) must be greater a parameter configured in the policy.
