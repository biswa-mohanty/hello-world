# JWT Token policy example

## Description
This policy encodes incoming HTTP headers as JWT claims in the JWT token and sets the token as a custom HTTP header.
It requires Auth0 JWT Java implementation library (https://github.com/auth0/java-jwt), so the policy can only be used with the on-prem runtimes.

## Configuration parameters
- `JWT Token Header Name` : the name of the HTTP header which will contain the resulting JWT token
- `Claim Headers` : comma-separated list of the incoming request headers which will be included as claims in the JWT token
- `Token Signing Algorithm` : must be either `HS256` or `RS256` (case-sensitive)
- `Secret` : Secret passphrase if the algorithm is `HS256`
- `Public Key Certificate` : A valid OpenSSL certificate which contains public key. Must be in the PEM format and include `-----BEGIN CERTIFICATE-----` and `-----END CERTIFICATE-----`
- `RSA Private Key` : An RSA private key. Must be in the PEM format and include `-----BEGIN RSA PRIVATE KEY-----` and `-----END RSA PRIVATE KEY-----`

The public certificate and private key pair may be generated using the following command:
`openssl req -x509 -newkey rsa -keyout key.pem -out cert.pem -days 100000`


