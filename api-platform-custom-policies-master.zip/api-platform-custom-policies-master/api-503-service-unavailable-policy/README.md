### 503 Service Unavailable Policy ###

This policy filters all API requests and returns a 503 status code. This policy is used when the backend API is under maintenance and you want to easily notify all clients that the service is unavailable. You can also set the Retry-After HTTP header to notify when the client should retry.

The value of this field can be either an HTTP-date or an integer number of seconds (in decimal) after the time of the response.

*Credit to Federico Donnarumma for the original policy code*

	Retry After	    Fri, 31 Dec 1999 23:59:59 GMT
or
	Retry After	    3600


#### Configuration

The policy configuration one parameters:

+  Retry-After - an HTTP-date or an integer number of seconds (in decimal) after the time of the response