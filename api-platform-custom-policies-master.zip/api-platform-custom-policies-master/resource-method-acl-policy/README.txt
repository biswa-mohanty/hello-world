As a part of configuration, the policy expects a comma-separated list of URI templates, e.g. /helloworld,/helloworld/{id} to be provided. The policy then attempts to match the request URI 
to one of the provided templates and verify the client_id, pattern and method combination against the ACL table in MySQL database.

The table CREATE statement is:

CREATE TABLE `ACL` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client_id` varchar(100) NOT NULL,
  `resource` varchar(200) DEFAULT NULL,
  `GET` varchar(1) DEFAULT NULL,
  `PUT` varchar(1) DEFAULT NULL,
  `POST` varchar(1) DEFAULT NULL,
  `DELETE` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

