# Method-level no-db acl policy

## What is this?
This Policy is similar to the resource-acl-policy in the same github with two major simplifications:
1. it does not require a database, and is configured for each API
2. it only works at the resource level, but is not method (HTTP verb) specific

## How to use?
1. Add the policy https://docs.mulesoft.com/api-manager/add-custom-policy-task
2. When applying the policy, add the ACL for each method in a multi-line syntax

The syntax follows the following multi-line pattern (spaces are optional):  
`username1: resource1, resource1/subresource1, resource2`  
`username2: resource1`  
`username3: resource1/subresource1`

## Limitations
This policy was done for a specific PoC and could be vastly improved by resolving these limitations:
1. This policy ony supports single users, not groups
2. It extracts usernames from a HTTP basic authentication header so will only work for this type of authentication. Note that the policy _does not_ verify the password and does not perform authentication.
3. You need to add all sub-resources in the URL. URI parameters are not supported (other than explicitely adding one entry per parameter value, which is often not realistic)
4. As stated above, it does not support method-level authorization, it will allow all HTTP verbs on the authorized method
