This module was built to process JWT token, validate the token using the signed key and also return the UPN
associated with the claim. This was done using google gson libraries. The module was built and tested with Gateway
1.3.1. This modules has a dependency on a specific version of apache commons that was not shipped as part of the 
gateway distribution and hence the apache commons code is included in the repo. 

