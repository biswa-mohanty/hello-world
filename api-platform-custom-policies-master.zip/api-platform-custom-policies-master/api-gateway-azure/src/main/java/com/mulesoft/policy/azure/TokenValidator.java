package com.mulesoft.policy.azure;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.security.PublicKey;
import java.security.SignatureException;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.HashMap;
import java.util.List;

import net.oauth.jsontoken.JsonToken;
import net.oauth.jsontoken.JsonTokenParser;
import net.oauth.jsontoken.crypto.RsaSHA256Verifier;
import net.oauth.jsontoken.crypto.SignatureAlgorithm;
import net.oauth.jsontoken.crypto.Verifier;
import net.oauth.jsontoken.discovery.VerifierProvider;
import net.oauth.jsontoken.discovery.VerifierProviders;

import org.apache.commons.codec.binary.CustomBase64;

import com.google.common.collect.Lists;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;

public class TokenValidator {
	
	
	private String inIssuer;
	private String certFile;
	private String audience;
	
	public String getInIssuer() {
		return inIssuer;
	}

	public void setInIssuer(String inIssuer) {
		this.inIssuer = inIssuer;
	}


	
	/**
	 * Load Certificate File & Public Key
	 */
	private PublicKey loadCertificate(){
		PublicKey publicKey = null;
		

		try {

			InputStream is = new ByteArrayInputStream(CustomBase64.decodeBase64(certFile));
			CertificateFactory f = CertificateFactory.getInstance("X.509");
			X509Certificate certificate = (X509Certificate)f.generateCertificate(is);
			publicKey = certificate.getPublicKey();
			
		} catch (CertificateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return publicKey;	
		
	}

	/**
	 * 
	 * @param token
	 * @return
	 */
	public HashMap verifySignedToken(String token) {
		
		String upn = null;
		
		
			
		//final Verifier hmacVerifier = new HmacSHA256Verifier(key.getBytes());
		PublicKey publicKey = loadCertificate();
		final Verifier hmacVerifier = new RsaSHA256Verifier(publicKey);
	
		   
        HashMap<String, Object> mp = new HashMap<String, Object>();
   
        VerifierProvider hmacLocator = new VerifierProvider() {

            public List<Verifier> findVerifier(String id, String key){
                return Lists.newArrayList(hmacVerifier);
            }
        };

        VerifierProviders locators = new VerifierProviders();
      //  locators.setVerifierProvider(SignatureAlgorithm.HS256, hmacLocator);
        locators.setVerifierProvider(SignatureAlgorithm.RS256, hmacLocator);
        net.oauth.jsontoken.Checker checker = new net.oauth.jsontoken.Checker(){

            public void check(JsonObject payload) throws SignatureException {
                // don't throw - allow anything
            }

        };

        //Ignore Audience does not mean that the Signature is ignored
        JsonTokenParser parser = new JsonTokenParser(locators,
                checker);

        JsonToken jt = null;
        try {

            jt = parser.verifyAndDeserialize(token);
 
        	JsonPrimitive upnPrim = jt.getParamAsPrimitive("upn");
        	
        	if ( upnPrim != null){
        		upn = jt.getParamAsPrimitive("upn").getAsString();
        		
        	}
        }catch(SignatureException se){
        	mp.put("INVALIDKEY", "INVALIDKEY");
        	return mp;
        }catch (Exception e) {
        	e.printStackTrace();
            //  throw new RuntimeException(e);
        	
          	return null;
        }
        
        if ( jt != null ){
            String jtIssuer = jt.getIssuer();
            if (jtIssuer != null){
            	if ( !jtIssuer.equals(inIssuer)){
            		System.out.println("Invalid Issuer - " + jtIssuer);
            		return null;
            		
            	}else{
            		mp.put("iss", jtIssuer);
            	}
            		
            }
            
            String jtAudience = jt.getAudience();
            if ( jtAudience != null){
            	if (!jtAudience.equals(audience)){
            		System.out.println("Invalid Audience - " + jtAudience);
            		return null;
            	}else{
            		mp.put("aud", jtAudience);
            	}
            }

        	JsonPrimitive upnPrim = jt.getParamAsPrimitive("upn");
        	
        	if ( upnPrim != null){
        		upn = jt.getParamAsPrimitive("upn").getAsString(); 
        		mp.put("upn", upn);
        	}
        	
        	if (jt.getParamAsPrimitive("iat") != null){
        		mp.put("iat",jt.getParamAsPrimitive("iat").toString());
        	}
        	if (jt.getParamAsPrimitive("nbf")!= null){
        		mp.put("nbf",jt.getParamAsPrimitive("nbf").toString());
        	}
        	if (jt.getParamAsPrimitive("exp") != null){
        		mp.put("exp",jt.getParamAsPrimitive("exp").toString());
        	}
        	if (jt.getParamAsPrimitive("ver") != null){
        		mp.put("ver",jt.getParamAsPrimitive("ver").toString());
        	}
        	if (jt.getParamAsPrimitive("tid") != null){
        		mp.put("tid",jt.getParamAsPrimitive("tid").toString());
        	}
        	if (jt.getParamAsPrimitive("oid") != null){
        		mp.put("oid",jt.getParamAsPrimitive("oid").toString());
        	}
        	if (jt.getParamAsPrimitive("sub") != null){
        		mp.put("sub",jt.getParamAsPrimitive("sub").toString());
        	}
        	if (jt.getParamAsPrimitive("given_name") != null){
        		mp.put("given_name",jt.getParamAsPrimitive("given_name").toString());
        	}
        	if (jt.getParamAsPrimitive("family_name") != null){
        		mp.put("family_name",jt.getParamAsPrimitive("family_name").toString());
        	}
        	if (jt.getParamAsPrimitive("name") != null){
        		mp.put("name",jt.getParamAsPrimitive("name").toString());
        	}
        	if (jt.getParamAsPrimitive("amr") != null){
        		mp.put("amr",jt.getParamAsPrimitive("amr").toString());
        	}
        	if (jt.getParamAsPrimitive("unique_name") != null){
        		mp.put("unique_name",jt.getParamAsPrimitive("unique_name").toString());
        	}
        	if (jt.getParamAsPrimitive("appid") != null){
        		mp.put("appid",jt.getParamAsPrimitive("appid").toString());
        	}
        	if (jt.getParamAsPrimitive("appidacr") != null){
        		mp.put("appidacr",jt.getParamAsPrimitive("appidacr").toString());
        	}
        	if (jt.getParamAsPrimitive("scp") != null){
        		mp.put("scp",jt.getParamAsPrimitive("scp").toString());
        	}
        	if (jt.getParamAsPrimitive("acr") != null){
        		mp.put("acr",jt.getParamAsPrimitive("acr").toString());
        	}
        }
 
      
		return mp;
	}

	public String getCertFile() {
		return certFile;
	}

	public void setCertFile(String certFile) {
		this.certFile = certFile;
	}

	public String getAudience() {
		return audience;
	}

	public void setAudience(String audience) {
		this.audience = audience;
	}

}
