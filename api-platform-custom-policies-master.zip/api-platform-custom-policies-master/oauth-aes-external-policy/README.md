# OAauth AES External Policy

This policy should be used to protect a specific API with OAuth 2.0.

"Scopes" is an optional value. You can specify a list of scopes separated by spaces. If defined, the scopes must be a sub-set of the ones supported by the AES external provider.

"Access Token validation endpoint url" is a mandatory field, where you specify the actual URL of the validation endpoint of the AES external provider.

The AES external provider server must be run on a Gateway 2.0 or later, pointing at the organization where the API to be protected is defined. The organization specified can be the master one (reccomended) or any sub-org.

The AES external provider server can be configured to use listeners or endpoints, with HTTP or HTTPs. The same is applicable to the validation endpoint.