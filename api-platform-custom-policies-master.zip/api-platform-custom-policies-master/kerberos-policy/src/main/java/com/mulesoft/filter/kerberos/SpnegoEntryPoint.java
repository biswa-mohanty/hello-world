/* 
* (c) 2017 MuleSoft, Inc. This software is protected under international copyright
 * law. All use of this software is subject to MuleSoft's Master Subscription Agreement
 * (or other master license agreement) separately entered into in writing between you and
 * MuleSoft. If such an agreement is not in place, you may not use the software.
 */

package com.mulesoft.filter.kerberos;

import java.util.HashMap;
import java.util.Map;

import org.mule.DefaultMuleMessage;
import org.mule.api.MuleContext;
import org.mule.api.MuleEventContext;
import org.mule.api.MuleMessage;
import org.mule.api.context.MuleContextAware;
import org.mule.api.lifecycle.Callable;

public class SpnegoEntryPoint implements Callable, MuleContextAware {

	MuleContext muleContext;

	@SuppressWarnings("unchecked")
	@Override
	public Object onCall(MuleEventContext eventContext) throws Exception {

		@SuppressWarnings("rawtypes")
		Map properties = new HashMap();
		properties.put("http.status", 401);
		properties.put("WWW-Authenticate", "Negotiate");

		MuleMessage response = new DefaultMuleMessage("", properties, muleContext);
		return response;
	}

	public void setMuleContext(MuleContext muleContext) {
		this.muleContext = muleContext;
	}

}
