/* 
* (c) 2017 MuleSoft, Inc. This software is protected under international copyright
 * law. All use of this software is subject to MuleSoft's Master Subscription Agreement
 * (or other master license agreement) separately entered into in writing between you and
 * MuleSoft. If such an agreement is not in place, you may not use the software.
 */

package com.mulesoft.filter.kerberos;

import java.io.UnsupportedEncodingException;

import org.mule.api.MuleEventContext;
import org.mule.api.MuleMessage;
import org.mule.api.lifecycle.Callable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.codec.Base64;
import org.springframework.security.kerberos.authentication.KerberosServiceRequestToken;

public class SpnegoAuthenticationFilter implements Callable {

	private AuthenticationManager authenticationManager;
	private static Logger logger = LoggerFactory.getLogger(SpnegoAuthenticationFilter.class);

	@Override
	public Object onCall(MuleEventContext eventContext) throws Exception {
		MuleMessage message = eventContext.getMessage();

		try {
			Authentication authentication = authenticate(message);
			if (authentication == null) {
				message.setInvocationProperty("spnego_authenticated", false);
			} else {
				message.setInvocationProperty("spnego_name", authentication.getName());
				message.setInvocationProperty("spnego_principal", authentication.getPrincipal());
				message.setInvocationProperty("spnego_authenticated", authentication.isAuthenticated());
				SecurityContextHolder.getContext().setAuthentication(authentication);
			}

		} catch (AuthenticationException e) {
			// That shouldn't happen, as it is most likely a wrong
			// configuration on the server side
			logger.warn("Negotiate Header was invalid", e);
			SecurityContextHolder.clearContext();
			message.setInvocationProperty("spnego_authenticated", "false");
		}

		return message;
	}

	public AuthenticationManager getAuthenticationManager() {
		return authenticationManager;
	}

	public void setAuthenticationManager(AuthenticationManager authenticationManager) {
		this.authenticationManager = authenticationManager;
	}

	public Authentication authenticate(MuleMessage message) {
		if (logger.isDebugEnabled()) {
			for (String prop : message.getInboundPropertyNames()) {
				logger.debug("Property: " + prop);
			}
		}
		String header = message.getInboundProperty("Authorization");

		if (header != null && header.startsWith("Negotiate ")) {
			if (logger.isDebugEnabled()) {
				logger.debug("Received Negotiate Header for request " + header);
			}
			byte[] base64Token;
			try {
				base64Token = header.substring(10).getBytes("UTF-8");
			} catch (UnsupportedEncodingException e1) {
				// TODO use a mule exception here
				throw new RuntimeException(e1);
			}
			byte[] kerberosTicket = Base64.decode(base64Token);
			KerberosServiceRequestToken authenticationRequest = new KerberosServiceRequestToken(kerberosTicket);

			if (logger.isDebugEnabled()) {
				logger.debug("principal: " + authenticationRequest.getPrincipal());
				logger.debug("credentials: " + authenticationRequest.getCredentials());
				logger.debug("name: " + authenticationRequest.getName());
			}
			return authenticationManager.authenticate(authenticationRequest);
		} else {
			return null;
		}

	}

}
