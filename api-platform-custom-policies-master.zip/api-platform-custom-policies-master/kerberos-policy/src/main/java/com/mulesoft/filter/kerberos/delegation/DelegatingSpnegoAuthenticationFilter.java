/* 
* (c) 2017 MuleSoft, Inc. This software is protected under international copyright
 * law. All use of this software is subject to MuleSoft's Master Subscription Agreement
 * (or other master license agreement) separately entered into in writing between you and
 * MuleSoft. If such an agreement is not in place, you may not use the software.
 */

package com.mulesoft.filter.kerberos.delegation;

import java.io.UnsupportedEncodingException;
import java.security.Principal;
import java.security.PrivilegedExceptionAction;

import javax.security.auth.Subject;

import org.ietf.jgss.GSSContext;
import org.ietf.jgss.GSSException;
import org.ietf.jgss.GSSManager;
import org.ietf.jgss.GSSName;
import org.ietf.jgss.Oid;
import org.mule.api.MuleEventContext;
import org.mule.api.MuleMessage;
import org.mule.api.lifecycle.Callable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.codec.Base64;
import org.springframework.security.kerberos.authentication.KerberosServiceRequestToken;

public class DelegatingSpnegoAuthenticationFilter implements Callable {

	private AuthenticationManager authenticationManager;
	private static Logger logger = LoggerFactory.getLogger(DelegatingSpnegoAuthenticationFilter.class);

	private String proxiedHost = new String("");

	@Override
	public Object onCall(MuleEventContext eventContext) throws Exception {
		MuleMessage message = eventContext.getMessage();
		String header = message.getInboundProperty("Authorization");
		boolean authenticated = false;
		if (header != null && header.startsWith("Negotiate ")) {
			if (logger.isDebugEnabled()) {
				logger.debug("Authorization Header: " + message.getInboundProperty("Authorization"));
			}
			byte[] base64Token;
			try {
				base64Token = header.substring(10).getBytes("UTF-8");
			} catch (UnsupportedEncodingException e1) {
				// TODO use a mule exception here
				throw new RuntimeException(e1);
			}
			byte[] kerberosTicket = Base64.decode(base64Token);
			KerberosServiceRequestToken authenticationRequest = new KerberosServiceRequestToken(kerberosTicket);

			Authentication authentication;
			try {
				authentication = authenticationManager.authenticate(authenticationRequest);
			} catch (AuthenticationException e) {
				// That shouldn't happen, as it is most likely a wrong
				// configuration on the server side
				logger.warn("Negotiate Header was invalid: " + header, e);
				SecurityContextHolder.clearContext();
				return false;
			}

			authenticated = authentication.isAuthenticated();
			if (logger.isDebugEnabled()) {
				logger.debug("Authenticated : " + authenticated + " for " + authentication.getName());
			}
			message.setInvocationProperty("spnego_authenticated", authenticated);
			SecurityContextHolder.getContext().setAuthentication(authentication);

			message.setOutboundProperty("Authorization",
					"Negotiate " + new String(Base64.encode(createServiceToken(proxiedHost))));
		}

		return message;
	}

	public AuthenticationManager getAuthenticationManager() {
		return authenticationManager;
	}

	public void setAuthenticationManager(AuthenticationManager authenticationManager) {
		this.authenticationManager = authenticationManager;
	}

	private static final Oid SPNEGO_OID;
	static {
		try {
			SPNEGO_OID = new Oid("1.3.6.1.5.5.2");
		} catch (GSSException e) {
			throw new IllegalStateException("Couldn't create SPNEGO Oid.", e);
		}
	}

	public byte[] createServiceToken(String serviceName) throws Exception {

		if (logger.isDebugEnabled()) {
			logger.debug("Initiating delegation process..");
		}

		KerberosServiceRequestToken authentication = (KerberosServiceRequestToken) SecurityContextHolder.getContext()
				.getAuthentication();
		DelegatedKerberosTicketValidation ticketValidation = (DelegatedKerberosTicketValidation) authentication
				.getTicketValidation();

		if (logger.isDebugEnabled()) {
			for (Principal p : ticketValidation.subject().getPrincipals()) {
				logger.debug("Principal found: " + p);
			}
		}

		Subject subject = ticketValidation.subject();

		return Subject.doAs(subject, new PrivilegedExceptionAction<byte[]>() {

			@Override
			public byte[] run() throws Exception {

				GSSManager manager = GSSManager.getInstance();

				// step 1 create Destination name
				GSSName name = manager.createName("HTTP@" + serviceName, GSSName.NT_HOSTBASED_SERVICE);

				// step 2 initiate new security context for destination service
				GSSContext context = manager.createContext(name.canonicalize(SPNEGO_OID), SPNEGO_OID,
						ticketValidation.getDelegationCredential(), GSSContext.INDEFINITE_LIFETIME);
				// step 3 request delegation
				context.requestCredDeleg(true);

				if (logger.isDebugEnabled()) {
					logger.debug("delegation set: " + context.getCredDelegState());
				}

				// step 4 generate new kerberos token
				byte[] serviceToken = context.initSecContext(authentication.getToken(), 0,
						authentication.getToken().length);

				if (logger.isDebugEnabled()) {
					logger.debug("Context src: " + context.getSrcName());
					logger.debug("Context target: " + context.getTargName());
					logger.debug("byte[]: " + new String(Base64.encode(serviceToken)));
				}

				context.dispose();
				return serviceToken;
			}
		});
	}

	public void setProxiedHost(String proxiedHost) {
		this.proxiedHost = proxiedHost;
	}
}