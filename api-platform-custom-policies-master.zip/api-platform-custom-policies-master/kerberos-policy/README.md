Kerberos Policies
----------------

Place spring-security-kerberos-core.1.0.1.RELEASE.jar & spring-security-kerberos-web.1.0.1.RELEASE.jar into the Mule folder libs/user/ or include them in the project to ensure they are accessible to Mule.

Don't forget your keytab

2 Policies included, one performs a straight kerberos authentication, one performs a kerberos delegation for a proxy use case
