# API Custom Policies Repository
====

## Objective
The idea for this repository is to start gathering all the custom policies that we built.
If you created a custom policy for the Anypoint API platform, please share it with us.


## Guidelines for sharing

Here are some guidelines that we need to follow in order for everyone to be able to use this:

1. Create a new directory with the policy code inside of it.
2. Add a README file to the policy directory that describes what the policy does and how to do it.
3. Finally, update the main README file to add your policy to the policy list.


## Policy List
1. afip-external-service-authentication-policy
2. api-503-service-unavailable-policy
3. api-gateway-azure
4. api-request-response-logging-for-all-proxy-type
5. att-custom-policies-with-sla
6. eid-token-custom-policy
7. external-api-rate-limiting-policy
8. external-jwt-cookie-policy
9. global-cors-custom-policy
10. jasig-cas-proxy-validation-policy
11. kerberos-policy
12. kerberos-spnego-policy
13. ldap-role-based-uber-policy
14. oauth-aes-external-policy
15. okta-oauth2-external-validation-policy
16. resource-method-acl-policy
17. saml-assertion-policy
18. sql-injection-policy
19. masking-policy
20. replace-policy
21. saml-assertion-validation-policy (No JKS, inline Cert)
22. jwt-validation-policy
23. simple-auth-token-validator-policy
24. ws-security-username-token-to-client-credentials

## More policies

 - https://github.com/mulesoft/api-policies
 - https://github.com/mulesoft/api-gw-exchange
 - https://github.com/mulesoft/template-banking-authorization-policy
 - https://github.com/mulesoft-consulting/bridgestone-token-mapping-policy
 - https://github.com/mulesoft-consulting/flex-onsite-poc/tree/master/src/custom-policies/saml-custom-policy
