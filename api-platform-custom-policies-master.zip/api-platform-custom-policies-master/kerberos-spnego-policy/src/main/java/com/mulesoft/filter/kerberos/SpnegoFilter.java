package com.mulesoft.filter.kerberos;

import org.mule.api.MuleMessage;
import org.mule.api.routing.filter.Filter;

import java.io.UnsupportedEncodingException;

import org.mule.api.MuleEventContext;
import org.mule.api.MuleMessage;
import org.mule.api.lifecycle.Callable;
import org.mule.api.routing.filter.Filter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.codec.Base64;
import org.springframework.security.kerberos.authentication.KerberosServiceRequestToken;


public class SpnegoFilter implements Filter {
	
	private AuthenticationManager authenticationManager;
    private static Logger logger = LoggerFactory.getLogger(SpnegoFilter.class);

	@Override
	public boolean accept(MuleMessage message) {
		System.out.println(message.getInboundPropertyNames());
		String header = message.getInboundProperty("Authorization");

		System.out.println("AUTH HEADER: " + header);

		boolean authenticated = false;
		if (header != null && header.startsWith("Negotiate ")) {
			if (logger.isDebugEnabled()) {
				logger.debug("Received Negotiate Header for request " + header);
			}
			byte[] base64Token;
			try {
				base64Token = header.substring(10).getBytes("UTF-8");
				//base64Token = header.substring(8).getBytes("UTF-8");

			} catch (UnsupportedEncodingException e1) {
				// TODO use a mule exception here
                throw new RuntimeException(e1);
			}
			byte[] kerberosTicket = Base64.decode(base64Token);
			KerberosServiceRequestToken authenticationRequest = new KerberosServiceRequestToken(
					kerberosTicket);
			Authentication authentication;
			try {
				authentication = authenticationManager
						.authenticate(authenticationRequest);
			} catch (AuthenticationException e) {
				// That shouldn't happen, as it is most likely a wrong
				// configuration on the server side
				logger.warn("Negotiate Header was invalid: " + header, e);
				SecurityContextHolder.clearContext();
				return false;
			}
			
			authenticated = authentication.isAuthenticated();
			
			System.out.println("AUTHENTICATED: " + authenticated);
			message.setInvocationProperty("spnego_authenticated", authenticated);
			
			SecurityContextHolder.getContext()
					.setAuthentication(authentication);
			
			return authenticated;
		} else {
			return false;
		}

	}

	public AuthenticationManager getAuthenticationManager() {
		return authenticationManager;
	}

	public void setAuthenticationManager(AuthenticationManager authenticationManager) {
		this.authenticationManager = authenticationManager;
	}
	
	

}
