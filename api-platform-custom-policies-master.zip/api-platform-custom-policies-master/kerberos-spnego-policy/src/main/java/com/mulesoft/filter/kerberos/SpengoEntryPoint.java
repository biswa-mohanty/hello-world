package com.mulesoft.filter.kerberos;

import java.util.HashMap;
import java.util.Map;

import org.mule.DefaultMuleMessage;
import org.mule.api.MuleContext;
import org.mule.api.MuleEventContext;
import org.mule.api.MuleMessage;
import org.mule.api.context.MuleContextAware;
import org.mule.api.lifecycle.Callable;

public class SpengoEntryPoint implements Callable, MuleContextAware  {

	MuleContext muleContext;
	
	@Override
	public Object onCall(MuleEventContext eventContext) throws Exception {
		
		Map properties = new HashMap();
		properties.put("http.status", 401);
		properties.put("WWW-Authenticate","Negotiate");
			
		MuleMessage response = new DefaultMuleMessage("",properties,muleContext);
		return response;
	}

	

	public void setMuleContext(MuleContext muleContext) {
		this.muleContext = muleContext;
	}
	
	

}
