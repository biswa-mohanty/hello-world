package com.nuskin.mule.gw.filter;

import org.mule.api.MuleEvent;
import org.mule.api.routing.filter.Filter;
import org.mule.api.routing.filter.FilterUnacceptedException;
import org.mule.config.i18n.Message;


public class EidPolicyViolation  extends FilterUnacceptedException
{
        public EidPolicyViolation(Message message, MuleEvent event, Filter filter)
        {
            super(message, event, filter);
        }
}

