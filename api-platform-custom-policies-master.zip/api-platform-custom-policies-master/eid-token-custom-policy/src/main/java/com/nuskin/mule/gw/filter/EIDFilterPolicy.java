package com.nuskin.mule.gw.filter;

import com.nse.common.util.Crypt;
import org.apache.log4j.Logger;
import org.mule.api.MuleContext;
import org.mule.api.MuleMessage;
import org.mule.api.context.MuleContextAware;
import org.mule.api.expression.ExpressionRuntimeException;
import org.mule.api.routing.filter.Filter;

public class EIDFilterPolicy implements Filter, MuleContextAware {
    private static final Logger LOGGER = Logger.getLogger(EIDFilterPolicy.class);
    private MuleContext muleContext;

    public EIDFilterPolicy() {
    }

    public boolean accept(MuleMessage message) {
        String sapId;
        String eid;
            try {
                eid = message.getInboundProperty("EID");
                if(eid == null){
                    eid = message.getInboundProperty("eid");
                }else{
                    String violationMessage = "Unable to obtain eid from request or header.";
                    message.setInvocationProperty("_eidViolationMessage", "{ \"error\": \"invalid_eid\", \"description\": \"" + violationMessage + "\" }");
                    LOGGER.info(violationMessage);
                    return false;
                }

            } catch (ExpressionRuntimeException ere) {
                String violationMessage = "Unable to obtain eid from request or header.";
                message.setInvocationProperty("_eidViolationMessage", "{ \"error\": \"invalid_eid\", \"description\": \"" + violationMessage + "\" }");
                LOGGER.info(violationMessage);
                return false;
            }

         sapId = Crypt.decode(eid);

         if(sapId.length() < 1){
             String violationMessage = "Invalid ID";
             message.setInvocationProperty("_eidViolationMessage", "{ \"error\": \"invalid_eid\", \"description\": \"" + violationMessage + "\" }");
             LOGGER.info(violationMessage);
             return false;
        }else{
             message.setOutboundProperty("validId", sapId);
              return true;
         }
    }

    public void setMuleContext(MuleContext muleContext) {
        this.muleContext = muleContext;
    }
}
