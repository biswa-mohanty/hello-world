package com.nuskin.mule.gw.filter;

import org.mule.api.MuleEvent;
import org.mule.api.MuleException;
import org.mule.api.transport.PropertyScope;
import org.mule.config.i18n.CoreMessages;
import org.mule.routing.MessageFilter;

public class EIDFilter
        extends MessageFilter
{
    public static final String IP_VIOLATION_MESSAGE_PROPERTY_NAME = "_eidViolationMessage";

    public EIDFilter() {}

    protected MuleException filterUnacceptedException(MuleEvent event)
    {
        String message = (String)event.getMessage().getProperty("_eidViolationMessage", PropertyScope.INVOCATION);
        return new EidPolicyViolation(CoreMessages.createStaticMessage(message), event, this.filter);
    }

    public void setEIDFilterPolicy(EIDFilterPolicy EIDFilterPolicy)
    {
        setFilter(EIDFilterPolicy);
    }
}
