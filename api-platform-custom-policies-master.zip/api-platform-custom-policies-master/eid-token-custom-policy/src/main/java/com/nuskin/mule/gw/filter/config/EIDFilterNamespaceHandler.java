package com.nuskin.mule.gw.filter.config;

import com.nuskin.mule.gw.filter.EIDFilter;
import org.mule.config.spring.handlers.AbstractMuleNamespaceHandler;
import org.mule.config.spring.parsers.specific.MessageFilterDefinitionParser;

public class EIDFilterNamespaceHandler extends AbstractMuleNamespaceHandler{
    public void init()
    {
        MessageFilterDefinitionParser parser = new MessageFilterDefinitionParser(EIDFilter.class);
        registerBeanDefinitionParser("filter", parser);
    }
}
