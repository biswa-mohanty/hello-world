# Custom HTTP Basic Security Manager

## Objective
The idea is to simulate the authentication of multiple users with specific roles that then will be accessible in the backend API without using an LDAP

## Configuration Window
![config window](http://oi66.tinypic.com/2qi4wsi.jpg)
